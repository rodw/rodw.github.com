This directory contains actual screen captures from the FATpick desktop app
at couple of different resolutions in both light and dark themes.

Each file is a 72 DPI JPG image of the specified dimensions.

These screenshots were taken with FATpick v2.2 (or later) running on a Mac OS X
computer. If they haven't been replaced it is reasonable to assume that they
are an adequate representation of the current app design, UX and look-and-feel.
